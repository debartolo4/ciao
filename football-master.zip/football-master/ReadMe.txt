This is the simple game known as Defend It.

How to play:

1) You are playing as a defender

2) You have to defend the ball

3) Don't let the ball fall down

4) Press Space Bar for making it go up

5) Each Time you press the Space Bar, it's velocity will increase. So it will be difficult for you to play.

6) You can't use space Bar before the center line. Press the Space Bar when the ball reaches the Dbox

7) Enjoy :)